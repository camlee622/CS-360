package com.example.project_one_final;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
// - Handles the login activity page -
public class Login extends AppCompatActivity implements View.OnClickListener {

    private InventoryAppDB database;  // Database
    private EditText userText; // username field
    private EditText passText; // password field
    private Button loginButton;      // login button
    private Button registerButton;   // Register button


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bring in the database that contains logins
        database = InventoryAppDB.getInstance(getApplicationContext());

        // Getting the login and register button setup
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Listening for login and register button
        loginButton.setOnClickListener(this);
        registerButton.setOnClickListener(this);

        // Getting the username and password fields setup
        userText = findViewById(R.id.userName);
        passText = findViewById(R.id.password);

    }

    @Override
    public void onClick(View view) {
        User userTest = new User();

        switch (view.getId()) {
            case R.id.loginButton: // If login button is clicked
                userTest.setUser(userText.getText().toString()); // Set username
                userTest.setPass(passText.getText().toString()); // Set password

                // If the user/pass combo exists in database
                if (database.checkUser(userTest)) {
                    Toast.makeText(getApplicationContext(), "Correct Login", Toast.LENGTH_LONG).show(); // Correct login message

                    // Opens inventory list
                    Intent intent = new Intent(this, InventoryList.class);
                    // Starting inventory intent
                    startActivity(intent);
                }
                else { // Incorrect combination
                    Toast.makeText(getApplicationContext(), "That username & password combination doesn't exist.", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.registerButton: // If register button is clicked
                userTest.setUser(userText.getText().toString()); // Set username
                userTest.setPass(passText.getText().toString()); // Set password

                database.addUser(userTest); // Add that user to the database
                Toast.makeText(getApplicationContext(), "You have registered! Welcome! Please login now.", Toast.LENGTH_LONG).show(); // Registration successful message
                break;
        }



    }

    // - Keeping this code if needed. Kept having issues. -
    /*
    public void onLoginClick(View view) {
        Users userTest = new Users();

        userTest.setUser(userText.getText().toString());
        userTest.setPass(passText.getText().toString());

        if (database.checkUser(userTest)) {
            Toast.makeText(getApplicationContext(), "Correct login", Toast.LENGTH_SHORT).show();

            // Opens inventory list
            Intent intent = new Intent(this, InventoryList.class);
            // Starting inventory intent
            startActivity(intent);
        }

        else {
            Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    public void onRegisterClick(View view) {

        Users userTest = new Users();

        userTest.setUser(userText.getText().toString());
        userTest.setPass(passText.getText().toString());

        database.addUser(userTest);
        // Opens inventory list
        Intent intent = new Intent(this, InventoryList.class);
        // Starting inventory intent
        startActivity(intent);

    }

    */
}