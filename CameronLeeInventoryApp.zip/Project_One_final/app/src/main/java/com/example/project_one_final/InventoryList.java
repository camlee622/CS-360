package com.example.project_one_final;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

// - Handles inventory list activity
public class InventoryList extends AppCompatActivity {

    // Creating two intents
    private Intent expandItemIntent; // Expand item intent
    private Intent newItemIntent;    // Add new item intent

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_list);

        // Load database
        InventoryAppDB database = InventoryAppDB.getInstance(getApplicationContext());

        // Load itemList using database
        List<Item> itemList = database.getItems(InventoryAppDB.SortOrder.ALPHABETIC);

        // Grid display using gridContainer
        GridLayout grid = findViewById(R.id.gridContainer);


        expandItemIntent = new Intent(this, ItemExpanded.class); // Expand item intent setup
        newItemIntent = new Intent(this, NewItem.class); // New item add intent setup

        // Iterate through item list
        for (final Item item: itemList) {

            // Creating button and setting name
            Button button = new Button(getApplicationContext());
            button.setText(item.getName());

            // Listen for button click
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    // Getting extras values for name and quantity
                    Bundle extras = new Bundle();
                    extras.putString("NAME", item.getName());
                    extras.putString("QUANTITY", item.getQuantity());

                    // Place extras and open item to view
                    expandItemIntent.putExtras(extras);
                    startActivity(expandItemIntent);
                }
            });

            grid.addView(button);
        }


        // Handles "add" button
        FloatingActionButton newItem = findViewById(R.id.newItem);
        // Listen for click
        newItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { // When clicked

                startActivity(newItemIntent); // Add item intent
            }
        });
    }
}