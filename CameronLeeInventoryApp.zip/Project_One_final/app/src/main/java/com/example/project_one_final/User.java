package com.example.project_one_final;

// - Handles user variables -
public class User {

    private long userId; // User ID
    private static String userName; // User name
    private static String password; // User password

    public User(){}


    // - Setters -
    public void setUserId(long id) { // Set user ID

        this.userId = id;
    }

    public void setUser(String user) { // Set user name

        this.userName = user;
    }

    public void setPass(String pass) { // Set pass
        this.password = pass;
    }


    // - Getters -
    public String getUser() { // Get user
        return userName;
    }

    public String getPass() { // Get pass
        return password;
    }

}
