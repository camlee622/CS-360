package com.example.project_one_final;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

// - Handles the expanded item activity -
public class ItemExpanded extends AppCompatActivity implements View.OnClickListener {

    private InventoryAppDB database;// Naming the database for import
    private TextView itemName;      // itemName textview
    private TextView itemQuantity;  // itemQuantity textview
    private TextView phoneNum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_view);

        // Loading the database that contains the items
        database = InventoryAppDB.getInstance(getApplicationContext());

        // Name & quantity created
        String name;
        String quantity;

        // Getting values from other activities and binding them to extras
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        // Setting name & quantity variables to correct key values
        name = extras.getString("NAME");
        quantity = extras.getString("QUANTITY");

        // Getting itemName setup
        itemName = findViewById(R.id.itemName);
        // Getting itemQuantity setup
        itemQuantity = findViewById(R.id.numOfItem);

        // Setting text for name using itemName
        itemName.setText(name);
        // Setting text for quantity using itemQuantity
        itemQuantity.setText(quantity);

        // Save, Minus, Add, Delete, Alert buttons
        Button save = findViewById(R.id.save);
        ImageButton minus = findViewById(R.id.minus);
        ImageButton add = findViewById(R.id.add);
        ImageButton delete = findViewById(R.id.delete);
        Button alert = findViewById(R.id.alert);

        // Listen for Save, Minus, Add, and Delete buttons
        save.setOnClickListener(this);
        minus.setOnClickListener(this);
        add.setOnClickListener(this);
        delete.setOnClickListener(this);
        alert.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        try {
            switch (view.getId()) {
                case R.id.save: // If save button clicked

                    // Update item name and quantity
                    Item update = new Item();
                    itemName = findViewById(R.id.itemName);
                    itemQuantity = findViewById(R.id.numOfItem);
                    update.setName(itemName.getText().toString());
                    update.setQuantity(itemQuantity.getText().toString());

                    // Add updated item to database
                    database.updateItem(update);

                    // Create new intent and load back into inventory list
                    Intent intent = new Intent(this, InventoryList.class);
                    startActivity(intent);
                    break;


                case R.id.minus: // If minus button clicked

                    int updateQuantity = Integer.parseInt(itemQuantity.getText().toString());
                    if (updateQuantity > 0) { // Item can't be negative

                        updateQuantity--; // Iterate number down 1

                        // Set new TEXT value
                        itemQuantity.setText(String.valueOf(updateQuantity));

                        // Set quantity and name to new values
                        Item minusItem = new Item();
                        minusItem.setQuantity(String.valueOf(updateQuantity));
                        minusItem.setName(itemName.getText().toString());

                        // Updated item & quantity added to database
                        database.updateItem(minusItem);
                    }
                    break;

                case R.id.add: // If add button clicked
                    updateQuantity = Integer.parseInt(itemQuantity.getText().toString());

                    updateQuantity++; // Iterate number up 1

                    // Set new TEXT value
                    itemQuantity.setText(String.valueOf(updateQuantity));

                    // Set quantity and name to new values
                    Item addItem = new Item();
                    addItem.setQuantity(String.valueOf(updateQuantity));
                    addItem.setName(itemName.getText().toString());

                    // Update item & quantity added to database
                    database.updateItem(addItem);
                    break;

                case R.id.delete: // If delete button clicked
                    Item deleteItem = new Item();
                    deleteItem.setName(itemName.getText().toString());
                    deleteItem.setQuantity(itemQuantity.getText().toString());

                    // Update database
                    database.deleteItem(deleteItem);

                    Intent intent1 = new Intent(this, InventoryList.class);
                    startActivity(intent1);
                    break;

                case R.id.alert:
                   //  Intent smsIntent = new Intent(this, sms_alerts.class);
                   //  startActivity(smsIntent);
                    break;
            }
        } catch (NumberFormatException e) { // Catch the try block
            e.printStackTrace();
        }

    }
}
