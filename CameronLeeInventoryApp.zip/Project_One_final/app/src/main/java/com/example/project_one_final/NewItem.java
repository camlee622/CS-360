package com.example.project_one_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// - Handles adding a new item activity
public class NewItem extends AppCompatActivity {

    private InventoryAppDB database; // Naming the database for import
    private TextView name;           // Name textview
    private TextView quantity;       // Quantity textview
    private Button enter;            // Enter button
    private Intent invIntent;        // New intent for inventory

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Loading the database that contains items
        database = InventoryAppDB.getInstance(getApplicationContext());

        // Creating intent that will open the inventory list
        invIntent = new Intent(this, InventoryList.class);

        // Getting the name setup
        name = findViewById(R.id.newItemName);
        // Getting the quantity setup
        quantity = findViewById(R.id.newItemQuantity);

        // Getting the enter button setup
        enter = findViewById(R.id.enter);
        // Listening for enter click
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Adding new item & setting name and quantity
                Item newItem = new Item();
                newItem.setName(name.getText().toString());
                newItem.setQuantity(quantity.getText().toString());

                // Adding item to database
                database.addItem(newItem);

                // Successfully added message
                Toast.makeText(getApplicationContext(), "Item added successfully", Toast.LENGTH_LONG).show();

                // Load back into the inventory list
                startActivity(invIntent);
            }
        });
    }
}
