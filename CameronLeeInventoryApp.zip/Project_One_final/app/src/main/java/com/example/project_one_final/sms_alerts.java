package com.example.project_one_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
/*
// TODO: Complete SMS Alerts function ** Could not finish before due date, kept breaking application **
public class sms_alerts extends AppCompatActivity implements View.OnClickListener {

    private InventoryAppDB database;
    private TextView itemQuantity;
    private TextView phoneNum;
    private Button returnButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_alerts);
        returnButton.findViewById(R.id.returnButton);



        database = InventoryAppDB.getInstance(getApplicationContext());
        boolean alertEnabled = false;

        phoneNum = findViewById(R.id.phoneNum);
        String number = phoneNum.getText().toString();

        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent invIntent = new Intent(this, InventoryList.class);


            }
        });


    }

    @Override
    public void onClick(View view) {

    }
}


 */