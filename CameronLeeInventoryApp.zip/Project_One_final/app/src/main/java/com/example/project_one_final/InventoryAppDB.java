package com.example.project_one_final;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

// - Handles the inventory database using SQLite
public class InventoryAppDB extends SQLiteOpenHelper {

    // Setting version, database name and creating database variable
    private static final int VERSION = 1;
    public static final String DATABASE_NAME = "inventory.db";
    private static InventoryAppDB database;

    // Instance for database
    public static InventoryAppDB getInstance(Context context) {
        if (database == null) {
            database = new InventoryAppDB(context);
        }
        return database;
    }

    public enum SortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC } // Sort order for database

    private InventoryAppDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Setting up Logins Table
    private static final class LoginsTable {
        private static final String TABLE = "Logins";           // Table name
        private static final String COL_ID = "_id";             // User id column
        private static final String COL_USER = "userName";      // Username column
        private static final String COL_PASSWORD = "password";  // Password column
    }

    // Setting up items table
    private static final class ItemsTable {
        private static final String TABLE = "items";        // Table name
        private static final String COL_NAME = "item_name"; // Item name column
        private static final String COL_QTY = "quantity";   // Item quantity column
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating logins table
        db.execSQL("create table " + LoginsTable.TABLE + " (" +
                LoginsTable.COL_ID + " integer primary key autoincrement," +
                LoginsTable.COL_USER + " ," +
                LoginsTable.COL_PASSWORD + " TEXT)");


        // Creating items table
        db.execSQL("create table " + ItemsTable.TABLE + " (" +
                ItemsTable.COL_NAME + " primary key," +
                ItemsTable.COL_QTY + " TEXT)");
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginsTable.TABLE);

        db.execSQL("drop table if exists " + ItemsTable.TABLE);
        onCreate(db);
    }

    // - Inventory methods -
    public List<Item> getItems(SortOrder order) {
        // New list for items
        List<Item> items = new ArrayList<>();

        // SQLite database named
        SQLiteDatabase db = this.getReadableDatabase();

        // Handles list order for items
        String selectedOrder;
        switch (order) {
            case ALPHABETIC:
                selectedOrder = ItemsTable.COL_NAME + " collate nocase";
                break;

            case UPDATE_DESC:
                selectedOrder = ItemsTable.COL_QTY + " desc";
                break;

            default: // Ascending
                selectedOrder = ItemsTable.COL_QTY + " asc";
                break;
        }

        String sql = "select * from " + ItemsTable.TABLE + " order by " + selectedOrder;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();

                item.setName(cursor.getString(0));
                item.setQuantity(cursor.getString(1));

                items.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return items;
    }


    // - Add item -
    public boolean addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemsTable.COL_NAME, item.getName());
        values.put(ItemsTable.COL_QTY, item.getQuantity());

        long id = db.insert(ItemsTable.TABLE, null, values);
        return id != -1;
    }

    // - Delete item -
    public void deleteItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemsTable.TABLE, ItemsTable.COL_NAME + " = ? ", new String[] {item.getName()});
    }

    // - Update item -
    public void updateItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ItemsTable.COL_NAME, item.getName());
        values.put(ItemsTable.COL_QTY, item.getQuantity());

        db.update(ItemsTable.TABLE, values, ItemsTable.COL_NAME + " = ?", new String[] {item.getName()});
    }


    // - Login methods -

    // Add user to database
    public void addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoginsTable.COL_USER, user.getUser());
        values.put(LoginsTable.COL_PASSWORD, user.getPass());
        long userId = db.insert(LoginsTable.TABLE, null, values);
        user.setUserId(userId);
    }

    // Check user against database
    public boolean checkUser(User user) {
        SQLiteDatabase db = getWritableDatabase();

        String selection = LoginsTable.COL_USER + " = ?";
        String[] selectionArgs = {user.getUser()};

        String sortOrder = LoginsTable.COL_ID + " DESC";

        Cursor cursor = db.query(
                LoginsTable.TABLE,
                null,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );



        // If username and password match in the database
        if (cursor.moveToFirst() && cursor.getString(1).equals(user.getUser())) {
            return cursor.getString(2).equals(user.getPass());
        }
        else
            return false;
    }

}
