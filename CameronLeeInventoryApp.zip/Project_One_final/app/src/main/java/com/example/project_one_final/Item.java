package com.example.project_one_final;

// - Handles items variables -
public class Item {

    private String iName; // item iName
    private String quantity; // item quantity

    public Item(){}

    // - Setters -
    public void setName(String name) { // Set iName

        this.iName = name;
    }

    public void setQuantity(String quantity) { // Set quantity

        this.quantity = quantity;
    }


    // - Getters -
    public String getName() {  // Get iName

        return iName;
    }

    public String getQuantity() { // Get quantity

        return quantity;
    }
}
